<div class=" clearfix p-1" >
	<div class="float-start">
		<div class="d-flex align-item-center justify-content-center">
			<div style="height: 160px;  width: 140px;" class=" border border-4 border-secondary bg-body-tertiary">			
				<img class="w-100 p-1" src="../assets/photos/client/tg/kcr.jpg" style="height: 110px;">
				<div>
					<p class="font-x-small text-center"><b>Sri. K.Chandrasekhar Rao</b> <span class="text-primary w-100">Hon'ble Chief Minister</span><br>Government of Telangana</p>
				</div>
			</div>
			<img src="../assets/photos/client/tg/ts_logo.png" style="height: 140px;">
		</div>
	</div>
	<div class="float-end">	
		<div class="d-flex align-item-center justify-content-center">
			<img src="../assets/photos/client/tg/ts_logo.png" style="height: 140px;">
			<div style="height: 160px;  width: 140px;" class=" border border-4 border-secondary bg-body-tertiary">			
				<img class="w-100 p-1" src="../assets/photos/client/tg/kcr.jpg" style="height: 110px;">
				<div>
					<p class="font-x-small text-center"><b>Sri. K.Chandrasekhar Rao</b> <span class="text-primary w-100">Hon'ble Chief Minister</span><br>Government of Telangana</p>
				</div>
			</div>

		</div>
	</div>
</div>

