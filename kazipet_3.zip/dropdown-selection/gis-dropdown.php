<div class="row d-flex align-items-center">
  <div class="col-12 p-0 ">
    <div class="row d-flex justify-content-end align-items-center">
      <div class="col-xl-3 col-lg-4 d-flex justify-content-end align-items-center">
        <!-- <p class="m-0"><span class="text-body-tertiary">Updated On : </span><span>12:12:53 25-04-2024</span></p> -->
      </div>
      <div class="col-xl-3 col-md-4 col-6 d-flex align-items-center">
        <?php
        include("phase-selection.php");
        ?>
      </div>
      <div class="col-xl-3 col-lg-4 col-6 d-flex align-items-center">
       <?php
       include("group_selection.php");
       ?>
     </div>
     <div  class="col-xl-3 col-md-4 col-12 mt-sx-2 mt-md-0 mt-xl-0 mt-2 d-flex align-items-center">
       <select class="form-select pointer" id="locationsDropdown" name="locationsDropdown">
         
       </select>
     </div>
   </div>
 </div>
</div>